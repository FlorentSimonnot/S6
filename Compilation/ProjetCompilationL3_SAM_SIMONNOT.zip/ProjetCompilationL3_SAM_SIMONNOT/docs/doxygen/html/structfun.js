var structfun =
[
    [ "args", "structfun.html#a898b215286a6574d95803a8ba019a0ea", null ],
    [ "MAXargs", "structfun.html#a234ea53da5de088dfacb77b9f7a3e7d3", null ],
    [ "name", "structfun.html#afdd40a771835cf5f3511c7ac6fb6e664", null ],
    [ "Nargs", "structfun.html#a7239f4accd8e685ac9d88cb0f1eca6be", null ],
    [ "return_type", "structfun.html#a3a30fedbb952e6b50ccb4f70a75cef05", null ]
];