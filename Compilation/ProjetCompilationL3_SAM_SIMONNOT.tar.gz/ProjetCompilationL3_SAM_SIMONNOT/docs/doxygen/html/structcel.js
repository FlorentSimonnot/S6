var structcel =
[
    [ "Cmax", "structcel.html#a708c0152509a4fc390cc7904be927b58", null ],
    [ "Csize", "structcel.html#a64088910a6c1c39223f36d17273377f3", null ],
    [ "Ctable", "structcel.html#a83cd4ff203668f9dbbed335c25af0d64", null ],
    [ "current_stack_address", "structcel.html#a2f9dadae50a6e7f11a73d87380851be4", null ],
    [ "next", "structcel.html#a3ac2fa6ca480a8d2f10024e97a0be547", null ],
    [ "STmax", "structcel.html#adbb368ad027ec24104f6cd5f7f7d2c0d", null ],
    [ "STsize", "structcel.html#a4a9f95fa763ad7614424fccd9b8d00a6", null ],
    [ "STtable", "structcel.html#a6812d40652d2bac79cfa87079b8cb7b9", null ]
];