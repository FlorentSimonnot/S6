var searchData=
[
  ['gettype',['getType',['../decl_8h.html#a0640a823bf6808b49b17c76dca5e507e',1,'decl.c']]]
];
