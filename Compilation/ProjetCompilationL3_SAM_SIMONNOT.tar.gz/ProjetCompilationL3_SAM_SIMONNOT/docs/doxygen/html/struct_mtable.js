var struct_mtable =
[
    [ "Mmax", "struct_mtable.html#aa6d3d414d4977af387a63b8563de99d4", null ],
    [ "Msize", "struct_mtable.html#ac6e9569a0a0277558387c0577d73b746", null ],
    [ "Mtable", "struct_mtable.html#ad0484a655e4eae46e745aebd6441b135", null ]
];