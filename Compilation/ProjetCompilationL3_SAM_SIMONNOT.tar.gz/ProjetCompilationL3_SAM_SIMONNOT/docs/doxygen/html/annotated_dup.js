var annotated_dup =
[
    [ "cel", "structcel.html", "structcel" ],
    [ "CONSTentry", "struct_c_o_n_s_tentry.html", "struct_c_o_n_s_tentry" ],
    [ "ftable", "structftable.html", "structftable" ],
    [ "fun", "structfun.html", "structfun" ],
    [ "MACROentry", "struct_m_a_c_r_oentry.html", "struct_m_a_c_r_oentry" ],
    [ "Mtable", "struct_mtable.html", "struct_mtable" ],
    [ "STentry", "struct_s_tentry.html", "struct_s_tentry" ]
];