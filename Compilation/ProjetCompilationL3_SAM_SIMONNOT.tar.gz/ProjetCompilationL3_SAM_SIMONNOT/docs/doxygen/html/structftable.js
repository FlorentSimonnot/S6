var structftable =
[
    [ "Fmax", "structftable.html#a38b6b9aaf8c248ce4eee091119712693", null ],
    [ "Fsize", "structftable.html#a34c8933e3338d011fd77921cb34ddc61", null ],
    [ "Ftable", "structftable.html#aca10ea87e4ecbebc41fa08736c462197", null ]
];