var struct_m_a_c_r_oentry =
[
    [ "name", "struct_m_a_c_r_oentry.html#afdd40a771835cf5f3511c7ac6fb6e664", null ],
    [ "type", "struct_m_a_c_r_oentry.html#ac765329451135abec74c45e1897abf26", null ],
    [ "value", "struct_m_a_c_r_oentry.html#ac4f474c82e82cbb89ca7c36dd52be0ed", null ],
    [ "valueFloat", "struct_m_a_c_r_oentry.html#ab271bf689e787edf8ddff375682937d2", null ]
];